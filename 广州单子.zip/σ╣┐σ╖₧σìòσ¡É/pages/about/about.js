// pages/run/run.js
Page({
  data: {
    name:'小鲤科技',
    add:'南昌市经济开发区双港东1180号',
    src:"",
    add_src:'../../image/定位.png',
    time:'08:00-22:00',
    Free_service :'免费服务',
    Free_service_src:"../../image/贴心服务.png",
    service_item1:"网站建设",
    service_item2:"微营销",
    service_item3:"小程序开发",
    tel: 18779115213,
    phone_src: "../../image/电话.png",
    wechat_src:"../../image/微信.png",

    introduce:'公司介绍：请花时间，尽力完成您的个人资料。一旦完成，您的个人资料，技能和工作经验将被雇主搜索，您还可以通过私人聊天，电子邮件，直播视频/语音/信息直接申请工作和沟通。我们将为您提供与雇主成功沟通所需的所有工具，以确保可靠的远程工作。',
    imgalist: ['https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1496287851&di=0a26048f586b852193cb5026d60c4fad&imgtype=jpg&er=1&src=http%3A%2F%2Fpic.58pic.com%2F58pic%2F12%2F74%2F05%2F99C58PICYck.jpg',
      'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1495693185413&di=0d0acdebf0f532edd0fcdb76265623c5&imgtype=0&src=http%3A%2F%2Fimg1.3lian.com%2Fimg013%2Fv3%2F2%2Fd%2F61.jpg',
      'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1495693185413&di=0d0acdebf0f532edd0fcdb76265623c5&imgtype=0&src=http%3A%2F%2Fimg1.3lian.com%2Fimg013%2Fv3%2F2%2Fd%2F61.jpg',
      'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1495693185413&di=0d0acdebf0f532edd0fcdb76265623c5&imgtype=0&src=http%3A%2F%2Fimg1.3lian.com%2Fimg013%2Fv3%2F2%2Fd%2F61.jpg',
      'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1495693185413&di=55835ae37fdc95a317b03f28162c0de1&imgtype=0&src=http%3A%2F%2Fimg4.duitang.com%2Fuploads%2Fitem%2F201307%2F12%2F20130712224237_nSjht.jpeg',
      'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1495693185410&di=e28cc03d2ae84130eabc26bf0fc7495f&imgtype=0&src=http%3A%2F%2Fpic36.photophoto.cn%2F20150814%2F0005018308986502_b.jpg', ]
  },
  /**
  *预览图片
  */
  previewImage: function (e) {
    var current = e.target.dataset.src;
    wx.previewImage({
      current: current,//当前显示图片的http链接
      urls: this.data.imgalist//需要预览的图片http链接列表
    })
  },

  /**
   * 页面的初始数据
   */


  /**
   * 生命周期函数--监听页面加载
   */
  phone: function (e) {
    var tel = e.target.dataset.tel;
    wx.makePhoneCall({
      phoneNumber: tel,
      success: function (res) {
        // success
      }
    })
  },
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onLoad: function (options) {
    // 页面初始化 options为页面跳转所带来的参数
    this.getLocation()
    console.log("onLoad")
    count_down(this);
  },
  //****************************
  openLocation: function () {
    wx.getLocation({
      type: 'gcj02', // 默认为 wgs84 返回 gps 坐标，gcj02 返回可用于 wx.openLocation 的坐标
      success: function (res) {
        wx.openLocation({
          latitude: 25.8622225, // 纬度，范围为-90~90，负数表示南纬
          longitude: 112.92472, // 经度，范围为-180~180，负数表示西经
          scale: 28, // 缩放比例
          address: '详细地址',
          name: '地址名',
          
        })
      },
    })
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
      return {
        title: '自定义分享标题',
        desc: '自定义分享描述',
        path: '/page/user?id=123'
      } 
      }
})